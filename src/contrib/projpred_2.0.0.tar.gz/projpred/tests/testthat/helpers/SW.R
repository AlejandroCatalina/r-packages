SW <- function(expr) capture.output(suppressWarnings(expr))
